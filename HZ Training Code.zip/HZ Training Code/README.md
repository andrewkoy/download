Prereq Items:

1. JDK 17
2. Latest Maven
3. HazelCast-Enterprise-5.3.6 binary (from usb drive or download at: https://repository.hazelcast.com/download/hazelcast-enterprise/hazelcast-enterprise-5.3.6.zip)
4. Latest IntelliJ IDEA IDE tool.
4. non-prod license key
5. Reliable Internet Connection

Training Purpose
1. Show how to configure hazelcast
   by setup cluster, username/password security, native memory (Enterprise feature), configure heap space and so on.

   config/hazelcast.xml (Search for PBB keyword)
   bin/common.bat (Search for PBB keyword)
   bin/common.sh (Search for PBB keyword)


2. Show how to run management center to connect to hazelcast cluster (via training-hzclientconfig.xml) and monitor the statistics.

3. How to setup dependency jar file

   pom.xml

4. How to open client connection to Hazelcast server cluster.

   Util.java

5. How to create map (cache container) and create indexing then load the data to cache

Training.java loadCache() function

6. How to query and fetch the data from cache

Training.java fetchFromCache() function

7. Either build jar file to try run, or right click on Training.java class to run directly.

===========================================================

Training Exercise:
Try load the cache with/without indexing then compare the performance.




