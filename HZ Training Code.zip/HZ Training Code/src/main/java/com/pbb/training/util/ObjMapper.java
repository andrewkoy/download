package com.pbb.training.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Top up ObjectMapper to provide more easy understanding way to do conversion between string/object or object/object
 *
 * @author GanYew
 *
 */
public class ObjMapper {
    private ObjMapper() {}

    /**
     * <p>Convert object to string
     * </p>
     * @param obj object need to convert
     * @return string in json represent object
     * @since 1.0
     */
    public static String objToStr(Object obj) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(obj);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static String objToPrettyStr(Object obj) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * <p>Convert string to Map<String,Object>
     * </p>
     * @param str json string
     * @return Map<String,Object>
     * @since 1.0
     */
    public static Map<String,Object> strToMap(String str) {
        if (str == null) {
            return new HashMap<>();
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readValue(str, Map.class);
        }
        catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return new HashMap<>();
    }

    public static List<Map<String,Object>> strToMapList(String str) {
        if (str == null) {
            return new ArrayList<>();
        }
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(str, new TypeReference<List<Map<String,Object>>>() {});
    }

    /**
     * <p>Convert Map<String,Object> to string
     * </p>
     * @param map HashMap
     * @return json string
     * @since 1.0
     */
    public static String mapToStr(Map<String,Object> map) {
        return objToStr(map);
    }

    /**
     * <p>Convert string to object
     * </p>
     * @param str json string
     * @param clazz as transform the string to object
     * @return dedicated object
     * @since 1.0
     */
    public static <T> T strToObj(String str, Class<?> clazz) {
        if (str == null) {
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        try {
            return (T) mapper.readValue(str, clazz);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }

    }

    /**
     * <p>Convert object to Map<String, Object>
     * </p>
     * @param obj object to convert
     * @return Map<String,Object>
     * @since 1.0
     */
    public static Map<String,Object> objToMap(Object obj) {
        if (obj == null) {
            return new HashMap<>();
        }

        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readValue(mapper.writeValueAsString(obj), Map.class);
        }
        catch (JsonProcessingException jpe) {
            jpe.printStackTrace();
        }
        return new HashMap<>();
    }

    /**
     * <p>Convert object to another object
     * </p>
     * @param obj object to convert
     * @param clazz indicate how to transform
     * @return Another object result
     * @since 1.0
     */
    public static <T> T objToDedicatedObj(Object obj, Class<?> clazz) {
        if (obj == null) {
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        return (T) mapper.convertValue(obj, clazz);
    }

    /**
     * <p>Convert Map<String,Object> to object
     * </p>
     * @param map HashMap to convert from
     * @param clazz indicate how to transform
     * @return Object result
     * @since 1.0
     */
    public static <T> T mapToObj(Map<String,Object> map, Class<?> clazz) {
        if (map == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        return (T) mapper.convertValue(map, clazz);
    }
}


