package com.pbb.training.util;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;

import java.security.SecureRandom;

public class Util {
    public static final String RANDSTR = "a1qX2eAd3sfQ9eWergWDC4fe4vW6gAhjyt45FDDS7uW8iSolbmm0Rzs9VVap1GNfo34zx2cH6vMYb3it7UrswH8qdQdfeZnu";

    public static final String RANDDIGIT = "012345678998765432103442343443423341332341126808547";

    public static HazelcastInstance getHazelCastClientInstance(String clusterId, String[] serverNameAndPorts, String username, String password) {
        ClientConfig config = new ClientConfig();
        if (!mkEmpty(username).equals("") && !mkEmpty(password).equals("")) {
            config.getSecurityConfig().setUsernamePasswordIdentityConfig(username,password);
        }
        config.setClusterName(clusterId);
        config.getNetworkConfig().addAddress(serverNameAndPorts);

        return HazelcastClient.newHazelcastClient(config);
    }

    public static String mkEmpty(String str) {
        return str == null ? "" : str;
    }

    public static String getRandStr(int num)
    {
        return getRandStr(num,false);
    }

    public static String getRandStr(int num, boolean digitOnly)
    {
        SecureRandom rand = new SecureRandom();
        StringBuilder result = new StringBuilder();

        String randStr = digitOnly ? RANDDIGIT : RANDSTR;

        for (int i = 1; i <= num; i++)
            result.append(randStr.charAt(rand.nextInt(randStr.length() - 2)));
        return result.toString();
    }

    public static int getIntRandom(int aStart, int aEnd){
        if ( aStart > aEnd ) {
            throw new IllegalArgumentException("Start cannot exceed End.");
        }

        SecureRandom rand = new SecureRandom();
        return rand.nextInt(aEnd - aStart + 1) + aStart;

    }
}
