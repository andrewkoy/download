mvn clean package
